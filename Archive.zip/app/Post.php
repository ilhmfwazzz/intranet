<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Post extends Model
{
    protected $fillable = ['userid','post'];
    public function user(){
        return $this->hasMany('App\Model\User' , 'id');
    }
    public function comments(){
        return $this->hasMany(Check::class);
    }
}
