@extends('layouts.app')
   
@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">POST SESUKA HATI</div>
                <div class="card-body">
                    <form method="post" id="postForm" action="{{ route('post') }}">
                    @csrf
                        <div class="form-group">
                            <input type ="text" id="post" name ="post" rows="2" cols="10" class="form-control" placeholder="What's on your mind?" required></textarea>
                        </div>
                        <div class="form-group">
                            <button type="submit" id="postBtn" class="btn btn-primary">POST</button>
                        </div>
                    </form>
                </div>
            </div>
            <div id="postList"></div>
        </div>
    </div>
</div>
@endsection
