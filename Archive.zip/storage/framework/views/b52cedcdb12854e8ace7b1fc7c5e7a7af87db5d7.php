
<?php $__env->startSection('content'); ?>
<div class="container">
    <?php if(session('success')): ?>
    <div class="alert alert-success">
        <strong><?php echo e(session('success')); ?></strong>
    </div>
    <?php endif; ?>
    <div class="row">
        <?php if(is_array($files) || is_object($files)): ?>
        <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4">
            <div class="card">

                <div class="card-body">
                    <strong class="card-title"><?php echo e($file->name); ?></strong>
                    <p class="card-text"><?php echo e($file->created_at); ?></p>
                    <form action="<?php echo e(route('deletefile', $file->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger">Delete</button>
                        <a href="<?php echo e(route('downloadfile',$file->id)); ?>" class="btn btn-primary">Download</a>
                    </form>


                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/u8569cji/domain/kontras.org/absensi.kontras.org/web/resources/views/file/sop.blade.php ENDPATH**/ ?>