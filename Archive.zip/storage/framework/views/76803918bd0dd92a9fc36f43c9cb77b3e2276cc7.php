<?php $__env->startPush('css'); ?>
<link href="//cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css" rel="stylesheet" type="text/css" />
<link href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.css" rel="stylesheet" type="text/css" />
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="row mb-3">
  <div class="col-lg-12 margin-tb mb-3">
    <div class="pull-left">
      <h2>Attendance Management</h2>
    </div>
    <?php if(!auth()->check() || ! auth()->user()->hasRole('Admin')): ?>
    <div class="pull-right">
      <a href="<?php echo e(route('attendances.create')); ?>">
        <input type="button" id="absen" value="Create New Attendance" class="btn btn-primary" />
      </a>
      <script type="text/javascript" defer="defer">
        var enableDisable = function() {
          var UTC_hours = new Date().getUTCHours() + 7;
          if (UTC_hours > 12 || UTC_hours < 6) {
            document.getElementById('absen').disabled = true;
          } else {
            document.getElementById('absen').disabled = false;
          }
        };
        setInterval(enableDisable, 1000 * 60);
        enableDisable();
        // 
      </script>
    </div>
    <?php endif; ?>
  </div>
  <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('absen-export')): ?>
  <div class="col-lg-12 margin-tb mb-3">
    <?php echo Form::model($attendances, ['method' => 'POST','route' => ['attendances.export']]); ?>

    <div class="row mb-3">
      <div class="col-md-6 col-sm-12">
        <input type="text" name="timestamp" id="reservation" class="form-control float-right" placeholder="Select date range" autocomplete="off">
      </div>
      <div class="col-md-6 col-sm-12">
        <button type="submit" class="btn btn-info">Export</button>
      </div>
    </div>
    <?php echo Form::close(); ?>

  </div>
  <?php endif; ?>
</div>
<?php if($message = Session::get('success')): ?>
<div class="alert alert-success">
  <p><?php echo e($message); ?></p>
</div>
<?php endif; ?>
<?php if($message = Session::get('danger')): ?>
<div class="alert alert-danger">
  <p><?php echo e($message); ?></p>
</div>
<?php endif; ?>
<table class="datatable table-bordered">
  <thead>
    <tr>
      <?php if(isset($attendances[0]->name)): ?>
      <th>Nama</th>
      <?php endif; ?>
      <th>Kategori</th>
      <th>Tanggal</th>
      <th>Keterangan</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $attendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <?php if(isset($attendance->name)): ?>
      <td><?php echo e($attendance->name); ?></td>
      <?php endif; ?>
      <?php switch($attendance->category):
      case (1): ?>
      <td>Work from Office</td>
      <?php break; ?>
      <?php case (2): ?>
      <td>Work from Home</td>
      <?php break; ?>
      <?php case (3): ?>
      <td>Rapat/Dinas</td>
      <?php break; ?>
      <?php case (4): ?>
      <td>Cuti/Tidak Masuk</td>
      <?php break; ?>
      <?php default: ?>
      <td>ERROR</td>
      <?php endswitch; ?>
      <?php
      $today = date('Ymd', strtotime("now"));
      $match_date = date('Ymd', $attendance->entry_date);
      if ($today == $match_date) {
      ?>
        <td>
          <label class="badge badge-success" style="font-size: 100%;"><?php echo date('l, Y-m-d H:i:s', $attendance->entry_date); ?></label>
        </td>
      <?php
      } else {
      ?>
        <td>
          <?php echo date('l, Y-m-d H:i:s', $attendance->entry_date); ?>
        </td>
      <?php } ?>
      <td><?php echo e($attendance->note); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
  <tfoot>
    <tr>
      <?php if(isset($attendances[0]->name)): ?>
      <th>Nama</th>
      <?php endif; ?>
      <th>Kategori</th>
      <th>Tanggal</th>
      <th>Keterangan</th>
    </tr>
  </tfoot>
</table>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"></script>
<script type="text/javascript" src="//cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
<script>
  $(function() {
    $('#reservation').daterangepicker().val('');
    $('.datatable').DataTable({
      initComplete: function() {
        this.api().columns().every(function() {
          var that = this;
          $('input', this.footer()).on('keyup change clear', function() {
            if (that.search() !== this.value) {
              that
                .search(this.value)
                .draw();
            }
          });
        });
      },
      "bStateSave": true,
      "fnStateSave": function(oSettings, oData) {
        localStorage.setItem('offersDataTables', JSON.stringify(oData));
      },
      "fnStateLoad": function(oSettings) {
        return JSON.parse(localStorage.getItem('offersDataTables'));
      },
      "ordering": false
    });
  });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/u8569cji/domain/kontras.org/absensi.kontras.org/web/resources/views/attendances/index.blade.php ENDPATH**/ ?>