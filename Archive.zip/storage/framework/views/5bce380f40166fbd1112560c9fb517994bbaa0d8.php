
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-4 col-sm-12 justify-content-center mx-auto text-center">
        <h2 class="mb-3">UPLOAD FILE DISINI YA</h2>
        <a href="<?php echo e(route('formfile')); ?>">
            <input type="button" value="UPLOAD" class="btn btn-primary" />
        </a>
    </div>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/u8569cji/domain/kontras.org/absensi.kontras.org/web/resources/views/file/index.blade.php ENDPATH**/ ?>