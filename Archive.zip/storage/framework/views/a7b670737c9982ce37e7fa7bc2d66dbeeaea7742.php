<?php $__env->startSection('content'); ?>
<?php if(count($errors) > 0): ?>
<div class="alert alert-danger">
    <strong>Whoops!</strong> There were some problems with your input.<br><br>
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>

<div class="container">
    <div class="row">
        <div class="col-md-4 col-sm-12 justify-content-center mx-auto text-center">
            <div class="card">
                <h5 class="card-header">File Upload</h5>
                <div class="card-body">
                    <form action="<?php echo e(route('uploadfile')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <strong>Category :</strong>
                                <select class="form-select form-select-lg mb-3" aria-label=".form-select-lg example" id='category' name='category'>
                                <?php if(is_array($file_category) || is_object($file_category)): ?>
                                <?php $__currentLoopData = $file_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value='<?php echo e($cat->id_file_category); ?>'><?php echo e($cat->category); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>    
                                </select>
                                <input type="file" name="file">                                                    
                            </div>
                            <button type="submit" class="btn btn-primary">UPLOAD</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/u8569cji/domain/kontras.org/absensi.kontras.org/web/resources/views/file/upload.blade.php ENDPATH**/ ?>